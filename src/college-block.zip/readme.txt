OTF and TTF: College Block
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

WAKE UP!! Class is in session! College Block is a modified version of Blockletter Tall featuring many new glyphs and of course serifs reminiscent of that used on collegiate sweatshirts. Kerning and European accents are included. Use it for your own tees or campus project. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: stylish, display, font, typeface, publishing, logo, title, book, cover, company, brand, branding, sans, serif, poster, headline, retro, movie, university, childrens, kids, teen, sorority, fraternity, beer, college, collegiate, famous, sweatshirt